# Nexoria ShiftPlanner PRO - no custom ProGuard rules required.
